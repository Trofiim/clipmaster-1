ClipMaster AI Android project scaffold

This project wraps the current web prototype in Android WebView and implements a native Android video file picker using ACTION_OPEN_DOCUMENT / onShowFileChooser.

To build APK:
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as a project in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Build > Build APK(s). Or run Gradle task :app:assembleDebug.
5. APK output: app/build/outputs/apk/debug/app-debug.apk

Build and install steps follow Android developer documentation. This environment did not have Android SDK or Gradle installed, so the APK could not be compiled or device-tested here.
